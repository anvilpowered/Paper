package me.machinemaker.commands.api.argument;

public class ObjectiveArgument implements MinecraftArgument<String> {
    // TODO helper methods to get Objective
}
