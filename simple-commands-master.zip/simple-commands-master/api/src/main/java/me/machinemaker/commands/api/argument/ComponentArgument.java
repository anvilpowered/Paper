package me.machinemaker.commands.api.argument;

import net.kyori.adventure.text.Component;

public class ComponentArgument implements MinecraftArgument<Component> {
}
