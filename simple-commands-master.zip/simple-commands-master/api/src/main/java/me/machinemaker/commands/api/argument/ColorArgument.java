package me.machinemaker.commands.api.argument;

import net.kyori.adventure.text.format.TextColor;

public class ColorArgument implements MinecraftArgument<TextColor> {
}
