package me.machinemaker.commands.api.argument;

import org.bukkit.block.BlockState;

public class BlockArgument implements MinecraftArgument<BlockState> {
}
