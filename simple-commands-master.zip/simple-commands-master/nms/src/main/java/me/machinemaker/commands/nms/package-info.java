@DefaultQualifier(NonNull.class)
package me.machinemaker.commands.nms;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.framework.qual.DefaultQualifier;
